package com.app.pojos;

public enum SeatType {
	BUSINESS, ECONOMY
}
