package com.app.pojos;

public enum PassengerType {
	ADULT, MINOR, SENIOR
}
